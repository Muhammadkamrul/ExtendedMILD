# Tuned classic baselines (V6 calibration, held-out test)

Data /home/kamrul/intact/mild/v5_final/dataset/dataset.csv: 30181 rows. Development [0, 21126), TEST [21126, 30181) -- the same split as confirm_v6.py.
Each method's label horizon was chosen on the inner validation of the development part only; thresholds at 1 FP step / 1440 ticks / intent (own scope), holdout calibration. Deterministic: one run each.

Calibration path: standard; false-alarm scope: own.

## Search on development data

     method  label_horizon   score  detection  disamb  fp_per_day  lead
     LR-OvR             35   57.12      40.00   39.53        1.64  6.28
 WKPI-Tuned             35 -264.79       4.76    0.00       13.63  0.07
Dist-Target             35 -516.72      17.71    9.30       24.81  0.99
     LR-OvR             38   51.58      36.19   39.53        2.45  5.73
 WKPI-Tuned             38 -305.05       2.86    0.00       15.27  0.00
Dist-Target             38 -516.72      17.71    9.30       24.81  0.99
     LR-OvR             42   55.49      41.90   39.53        2.18  5.67
 WKPI-Tuned             42 -263.24       7.62    0.00       13.63  0.25
Dist-Target             42 -516.72      17.71    9.30       24.81  0.99
     LR-OvR             46   54.80      44.76   39.53        2.73  5.76
 WKPI-Tuned             46 -221.74      11.43    0.00       12.00  0.75
Dist-Target             46 -516.72      17.71    9.30       24.81  0.99
     LR-OvR            120  -38.16      10.52    0.00        4.36  1.96
 WKPI-Tuned            120 -386.27      21.90    0.00       19.09  1.33
Dist-Target            120 -516.72      17.71    9.30       24.81  0.99

## Held-out test

     method  label_horizon  detection  disamb  fp_per_day  lead  det_analytics  det_api  det_telemetry
     LR-OvR             35      37.33   50.00        3.18  7.24          100.0      2.6            9.4
Dist-Target             35      15.59    8.33       28.15  1.73            0.0     12.8           34.0
 WKPI-Tuned             46      21.61    1.39        7.32  0.75            0.0      2.6           62.3

